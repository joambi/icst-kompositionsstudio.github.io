# ICST Ambi Motion Markers Test Protocol

This protocol is meant for repeatable release testing of the `ICST Ambi Motion Markers`
workflow in REAPER.

## Test setup

1. Insert `AmbiEncoder_64` on a track.
2. Enable OSC input in the plugin.
3. Import these scripts into REAPER:
   - `JS_Ambi_Motion_Marker_GUI.lua`
   - `JS_Import_Ambi_Markers_From_CSV.lua`
4. Install `python-osc`.
5. Set the Python path in the GUI.
6. Confirm that GUI OSC port and plugin OSC port match.

## Test data

Use either:

- `Scripts/examples/ambi_markers_aed_example.csv`
- `Scripts/examples/ambi_markers_xyz_example.csv`

## Test 1: CSV import

1. Open `ICST Ambi Motion Markers`.
2. Click `Load CSV`.
3. Choose one of the example CSV files.
4. Verify markers appear at the correct timeline positions.
5. Verify repeated import replaces matching markers instead of duplicating them.

Expected:

- marker count matches CSV cue count
- source data is shown in compact list form
- no duplicate markers are created for matching time/index entries

## Test 2: Send pair

1. Click one marker row on the left to set `S`.
2. Click a later marker row on the right to set `E`.
3. Click `Set Selection`.
4. Click `Send pair`.

Expected:

- the plugin source position moves visibly
- only the selected segment is previewed
- no automation is written

## Test 3: Send series

1. Set `S` on the first marker of the phrase.
2. Click `Send series`.

Expected:

- preview continues through all following segments
- playback stops at the last marker
- motion matches the marker sequence

## Test 4: Record pair

1. Select the AmbiEncoder track.
2. Set `S` and `E`.
3. Click `Record pair`.

Expected:

- REAPER transport runs
- plugin movement is visible
- automation lanes receive data

## Test 5: Record series

1. Select the AmbiEncoder track.
2. Set `S` on the first cue to record.
3. Click `Record series`.

Expected:

- transport runs through the whole series
- recorded movement matches `Send series`
- automation is written for each segment

## Test 6: Console toggle

1. Enable console output.
2. Trigger `Send pair`.
3. Disable console output.
4. Trigger `Send pair` again.

Expected:

- console logs appear only while enabled

## Regression checks

- marker panel layout stays inside frame
- English labels are visible and not clipped
- `Load CSV` opens file chooser
- AED CSV and XYZ CSV both import correctly
- existing automation does not cause visible preview jitter

## Release decision

Release is ready when:

- all six tests pass
- no clipped controls are visible
- bundle zip opens and contains all required files
